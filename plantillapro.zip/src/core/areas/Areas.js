import React,{Fragment} from 'react';
import Modal from './Modal'

const Areas= () =>{
    
    return(
        <div className="card">
            <div className="card-header">
                <Modal/>
            </div>
            <div className="card-body">
                  
            </div>
        </div>
    );
}

export default Areas;